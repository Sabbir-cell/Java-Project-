package mid;

import java.util.Scanner;

class Name {


    public static void main(String args[]) {

        Scanner userInput = new Scanner(System.in);
        System.out.println("Enter how many student you want to take");
        int user = userInput.nextInt();

        Student[] arr;
        arr = new Student[100];


        // Creating actual student objects


        for (int i = 0; i < user; i++) {
            System.out.println("Enter information for array index : " + i);
            System.out.println("Enter User ID");
            int userID = userInput.nextInt();
            System.out.println("Enter User Name");
            String userName = userInput.next();
            System.out.println("Enter User NID");
            int userNID = userInput.nextInt();
            System.out.println("Enter User Age");
            String userAge = userInput.next();
            arr[i] = new Student();
            arr[i].setData(userID, userName, userNID, userAge);
        }

        System.out.println("Enter NID to insert course");
        int nid = userInput.nextInt();

        Student student = new Student();

        for (int index = 0; index < arr.length; index++) {
            if (student.nid == nid) {
                System.out.println("Enter course you want to insert");
                String course = userInput.next();
                arr[index].setCourse(course);
            }
        }


        for (int i = 0; i < user; i++) {
            System.out.println("Student data in student array : " + i);
            arr[i].display();
        }

    }
}

class Student {


    public int id;
    public int nid;
    public String name;
    public String age;
    public String course;

    public void setData(int id, String name, int nid, String age) {
        this.id = id;
        this.name = name;
        this.nid = nid;
        this.age = age;

    }

    public int getNID(int nid) {
        return this.nid = nid;
    }


    public void setCourse(String course) {
        this.course = course;
    }


    public void display() {

        System.out.println("ID: " + id
                + "Name: " + name
                + "NID: " + nid
                + "Age: " + age
                + "Course: " + course);

    }
}